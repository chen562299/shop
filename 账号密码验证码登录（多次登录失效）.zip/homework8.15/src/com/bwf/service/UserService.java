package com.bwf.service;

import org.apache.catalina.User;

import com.bwf.bean.UserInfo;

public interface UserService {
	public UserInfo Login(String userName,String userPsw);
	public boolean  update(UserInfo user,String id);
}
