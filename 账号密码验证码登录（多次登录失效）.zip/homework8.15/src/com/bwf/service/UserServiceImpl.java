package com.bwf.service;

import com.bwf.bean.UserInfo;
import com.bwf.dao.UserDao;
import com.bwf.dao.UserDaoImpl;

public class UserServiceImpl implements UserService {
	UserDao dao=new UserDaoImpl();
	@Override
	public UserInfo Login(String userName, String userPsw) {
		// TODO Auto-generated method stub
		return dao.selectByUser(userName,userPsw);
	}
	@Override
	public boolean update(UserInfo user,String id) {
		if(dao.update(user,id)>0){
			return true;
		}
		return false;
	}



}
