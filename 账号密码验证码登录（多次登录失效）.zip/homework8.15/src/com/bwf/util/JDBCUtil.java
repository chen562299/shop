package com.bwf.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class JDBCUtil {
	
	private static final String URL = "jdbc:mysql://localhost:3306/bwf";
	
	private static final String USER_NAME = "root";
	
	private static final String USER_PWD = "123";
	
	public static Connection conn;
	
	public static ResultSet rs;
	
	public static PreparedStatement ps;
	
	//加载
	static{
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//连接
	public static Connection getConnection(){
		
		try {
			conn = DriverManager.getConnection(URL, USER_NAME, USER_PWD);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	//关闭
	public static void closeConnection() throws Exception{
		
		if(ps != null && !ps.isClosed()){
			ps.close();
		}
		if(conn != null && !conn.isClosed()){
			conn.close();
		}
	}
	
	//更改
	public static int excuteUpdate(){
		
		try {
			
			return ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				closeConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}
	//查看
	public static ResultSet select(){
		
		try {
			return ps.executeQuery();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
	

}
