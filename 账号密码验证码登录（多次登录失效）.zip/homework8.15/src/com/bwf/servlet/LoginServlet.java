package com.bwf.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bwf.bean.UserInfo;
import com.bwf.service.UserService;
import com.bwf.service.UserServiceImpl;


/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	request.setCharacterEncoding("utf-8");
	String userName=request.getParameter("userName");
	String userPsw=request.getParameter("userPsw");
	
	String code=request.getParameter("code");
	
	//验证码
	String codeSession =(String) request.getSession().getAttribute("code");
	
	if(code == null || codeSession == null      || !code.equals(codeSession)) { 
		request.setAttribute("msg", "验证码错误");
		request.getSession().removeAttribute("code");
		request.getRequestDispatcher("Login").forward(request, response);
	}else{// 调用后台业务层的方法进行用户名和密码的校验
		UserService userService=new UserServiceImpl();
		UserInfo user= new UserInfo();
		HttpSession session =request.getSession();
		String id=session.getId();
		user = userService.Login(userName, userPsw);
		if(user!=null){
			//登录成功，添加session
			userService.update(user, id);
			
			session.setAttribute("userInfo",user);
			request.getSession().removeAttribute("code");
			response.sendRedirect("LoginSucceed");
		}else {
			request.getSession().removeAttribute("code");
			request.setAttribute("msg", "用户名或者密码错误");
			request.getRequestDispatcher("Login").forward(request,response); 
		}
	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
