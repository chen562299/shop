package com.bwf.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bwf.bean.UserInfo;
import com.bwf.service.UserService;
import com.bwf.service.UserServiceImpl;
import com.sun.javafx.geom.PickRay;

/**
 * Servlet implementation class LoginSucceed
 */
@WebServlet("/LoginSucceed")
public class LoginSucceed extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginSucceed() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		PrintWriter out= response.getWriter();
		HttpSession session =request.getSession();
		    UserInfo user=(UserInfo) session.getAttribute("userInfo");
		    
		out.println("<html>");
		out.println("<head><meta charset='utf-8'></head>");
		out.println("<body>");
		
		if(session.getAttribute("userInfo")!=null){
			String id=session.getId();
			UserService userserv=new UserServiceImpl();
			UserInfo userinfo=userserv.Login(user.getUserName(), user.getUserPsw());
			
			if(userinfo.getSession().equals(id)){
				out.println("欢迎"+user.getUserName());
				out.println("<img style='width:100px;heigh:100px;'  src=image/"+user.getUserImage()+">");
			}else {
				response.sendRedirect("Login");
			}
		}else {
			response.sendRedirect("Login");
		}
		out.println("</body>");
		out.println("</html>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
