package com.bwf.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setCharacterEncoding("utf-8");
		PrintWriter out= response.getWriter();
		out.println("<html>");
		out.println("<head><meta charset='UTF-8'></head>");
		out.println("<script type='text/JavaScript'>");
		out.println("function change() {  document.getElementById('code').src = 'Yanzhengma? t=' + Math.random();}");
		out.println("</script>");
		out.println("<div id='content'>");//跳转页面
		out.println("<form action='LoginServlet' method='post'>");
		out.println("<p>用&nbsp;&nbsp;户：<input type='text' name='userName'>");
		out.println("<p>密&nbsp;&nbsp;码：<input type='password' name='userPsw'>");
		out.println("<p>验证码：<input type='text' name='code' size='11'>");
		out.println(" <a href='javascript:change()'><img id='code' alt=''  src='Yanzhengma' /> 看不清楚换一个</a>");
		out.println("<p><input type='submit' value='登录'><input type='reset' value='重置' /></p>");
		out.println("</form></div>");
		out.println("</body>");
		out.println("</html>");
		
		String msg = (String)request.getAttribute("msg");
		if(msg!=null&&msg.length()>0){
			out.println("<font color='red'>"+msg +"</font>");	
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
