package com.bwf.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import com.bwf.bean.UserInfo;
import com.bwf.util.JDBCUtil;

public class UserDaoImpl implements UserDao {

	@Override
	public UserInfo selectByUser(String userName, String userPsw) {
		 
		try {
			JDBCUtil.ps = JDBCUtil.getConnection().prepareStatement("select * from userInfo where userName =? and userPsw=? ");
			JDBCUtil.ps.setString(1, userName);
			JDBCUtil.ps.setString(2, userPsw);
			ResultSet rs = JDBCUtil.select();
			if(rs.next()){
				UserInfo user=new UserInfo();
				
				user.setUserName(rs.getString(1));
				
				user.setUserPsw(rs.getString(2));
				
				user.setUserImage(rs.getString(3));
				user.setSession(rs.getString(4));
				rs.close();
				return user;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				JDBCUtil.closeConnection();
				
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public int update(UserInfo user,String id) {
		try {
			
				JDBCUtil.ps = JDBCUtil.getConnection().prepareStatement("update userinfo set session=?  WHERE userName=?");
				JDBCUtil.ps.setString(1, id);
				JDBCUtil.ps.setString(2, user.getUserName());
				int x=JDBCUtil.excuteUpdate();
				return x;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally {
			try {
				JDBCUtil.closeConnection();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return 0;
	}

}
