package com.bwf.dao;

import com.bwf.bean.UserInfo;

public interface UserDao {
	public UserInfo selectByUser(String userName,String userPsw);
	public int update(UserInfo user,String id);
}
