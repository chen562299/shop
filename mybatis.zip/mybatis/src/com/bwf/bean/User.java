package com.bwf.bean;

public class User{

	private int uid;
	private String name;
	private String userName;
	private String  userPsw;
	private String userImage;
	private String session;
	private String email;
	private String telephone;
	private String sex;
	private String birthday;
	private String state;
	
	
	@Override
	public String toString() {
		return "User [uid=" + uid + ", name=" + name + ", userName=" + userName + ", userPsw=" + userPsw
				+ ", userImage=" + userImage + ", session=" + session + ", email=" + email + ", telephone=" + telephone
				+ ", sex=" + sex + ", birthday=" + birthday + ", state=" + state + "]";
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserPsw() {
		return userPsw;
	}
	public void setUserPsw(String userPsw) {
		this.userPsw = userPsw;
	}
	public String getUserImage() {
		return userImage;
	}
	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	public String getSession() {
		return session;
	}
	public void setSession(String session) {
		this.session = session;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	
	
	

}
