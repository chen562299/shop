package com.bwf.bean;

public class Notice {
	private int noticeId;
	private String NoticePhoto;

	public int getNoticeId() {
		return noticeId;
	}

	public void setNoticeId(int noticeId) {
		this.noticeId = noticeId;
	}

	public String getNoticePhoto() {
		return NoticePhoto;
	}

	public void setNoticePhoto(String noticePhoto) {
		NoticePhoto = noticePhoto;
	}
}
